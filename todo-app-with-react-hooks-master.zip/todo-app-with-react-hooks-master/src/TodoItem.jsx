import React from 'react'

const TodoItem = ({item}) => (
    <div class="todoItem">{item}</div>
);

export default TodoItem;