# React Hooks: what's all the fuss about?

This is a trivial example of a Todo List application in two versions: with and without hooks that I'm using for a talk.

See the slides here: https://raw.githubusercontent.com/isocra/todo-app-with-react-hooks/master/slides/slides.html